(() => {
  "use strict";
  self.fallback = async (e) =>
    "document" === e.destination
      ? caches.match("/offline.html", { ignoreSearch: !0 })
      : Response.error();
})();

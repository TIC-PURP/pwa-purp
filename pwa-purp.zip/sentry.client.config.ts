/* import * as Sentry from "@sentry/nextjs"

Sentry.init({
  dsn: "https://212a921d236eb4b36831f918e6cc7b5f@o4509788384788480.ingest.us.sentry.io/4509788385837056",
  tracesSampleRate: 1.0, // 1.0 = 100% de las transacciones, puedes bajarlo en producción
  integrations: [],
  tunnel: "/monitoring",
  // Puedes activar esta opción para ver errores solo en producción:
  // enabled: process.env.NODE_ENV === "production",
})
 */
